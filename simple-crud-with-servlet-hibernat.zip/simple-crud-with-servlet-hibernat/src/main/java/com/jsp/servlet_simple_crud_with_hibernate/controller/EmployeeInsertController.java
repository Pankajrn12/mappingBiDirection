package com.jsp.servlet_simple_crud_with_hibernate.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jsp.servlet_simple_crud_with_hibernate.dto.Employee;
import com.jsp.servlet_simple_crud_with_hibernate.service.EmployeeService;

@WebServlet(value = "/empDetails")
public class EmployeeInsertController extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String gender = req.getParameter("gender");
		
		Employee employee = new Employee();
		
		employee.setEmpId(id);
		employee.setEmpName(name);
		employee.setEmpEmail(email);
		employee.setEmpGender(gender);
		
		EmployeeService employeeService = new EmployeeService();
		
		PrintWriter printWriter = resp.getWriter();
		
		printWriter.write("<html><body>");
		
		employeeService.insertEmployee(employee);
		
		printWriter.write("<h3 style='color:green'>Data-Inserted-Successfully</h3>");
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("employee-details.jsp");
		dispatcher.forward(req, resp);
		
	}
}
