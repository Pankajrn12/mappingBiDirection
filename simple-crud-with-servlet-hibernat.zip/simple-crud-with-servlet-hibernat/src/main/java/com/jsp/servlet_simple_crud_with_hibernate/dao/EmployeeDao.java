package com.jsp.servlet_simple_crud_with_hibernate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jsp.servlet_simple_crud_with_hibernate.dto.Employee;
public class EmployeeDao {

	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Pankaj");
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction = entityManager.getTransaction();

	// insertMethod
	public void insertEmployee(Employee employee) {

		entityTransaction.begin();
		entityManager.persist(employee);
		entityTransaction.commit();
	}

	// updateMethod
	public void updateEmployee(int id, Employee employee) {

		Employee employee2 = entityManager.find(Employee.class, id);

		if (employee2 != null) {

			entityTransaction.begin();
			employee2.setEmpName(employee.getEmpName());
			employee2.setEmpGender(employee.getEmpGender());
			entityManager.merge(employee2);
			entityTransaction.commit();
		}
	}

	// getById
	public int getById(int id) {
		
		Employee employee2 = entityManager.find(Employee.class, id);
		if (employee2 != null) {
			
			return employee2.getEmpId();
		}else {
			return 0;
		}
	}
	
	//displayMethod
	public List<Employee> displayEmployee(){
		
		String select = "Select e From Employee e";
		
		return entityManager.createQuery(select,Employee.class).getResultList();
	}
}
