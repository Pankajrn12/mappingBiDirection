package com.jsp.servlet_simple_crud_with_hibernate.service;

import com.jsp.servlet_simple_crud_with_hibernate.dao.EmployeeDao;
import com.jsp.servlet_simple_crud_with_hibernate.dto.Employee;
public class EmployeeService {

	EmployeeDao employeeDao = new EmployeeDao();

	// insertMethod
	public void insertEmployee(Employee employee) {

		employeeDao.insertEmployee(employee);

	}

	// getById
	public int getById(int id) {
		
		return employeeDao.getById(id);
		
	}
}
