package com.jsp.servlet_simple_crud_with_hibernate.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jsp.servlet_simple_crud_with_hibernate.dao.EmployeeDao;
import com.jsp.servlet_simple_crud_with_hibernate.dto.Employee;

@WebServlet(value = "/empUpdate")
public class EmployeeUpdateController extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int id = Integer.parseInt(req.getParameter("id"));
		
		String name = req.getParameter("name");
		
		String email = req.getParameter("email");
		
		String gender = req.getParameter("gender");
		
		Employee employee = new Employee();
		
		employee.setEmpGender(gender);
		employee.setEmpName(name);
		
		EmployeeDao employeeDao = new EmployeeDao();
		
		PrintWriter printWriter = resp.getWriter();
		
		printWriter.write("<html><body>");
		
		int idDatabase = employeeDao.getById(id);
		System.out.println("idDatabase = "+idDatabase+"\t"+"passingId = "+id);
		if(idDatabase!=0) {
			
			employeeDao.updateEmployee(id, employee);
			printWriter.write("<h3>Employee Name "+employee.getEmpName()+" and employeeGender"+employee.getEmpGender()+" is updated succesfully</h3>");
			RequestDispatcher dispatcher = req.getRequestDispatcher("update-employee.jsp");
			dispatcher.include(req, resp);
		}else {
			printWriter.write("<h3 style='color:red'>Given Id "+id+" is not present</h3>");
			RequestDispatcher dispatcher = req.getRequestDispatcher("update-employee.jsp");
			dispatcher.include(req, resp);
		}
		
		printWriter.write("</body></html>");
	}
}
